MODULE Module1
    CONST robtarget Reposo:=[[425.19,0,630],[0.707106781,0,0.707106781,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget PP:=[[10,30,20],[0,0,1,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget PB3:=[[0,150,0],[0,-0.707106781,0.707106781,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget PB2:=[[0,0,0],[0,-0.707106781,0.707106781,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget PB1:=[[0,-150,0],[0,-0.707106781,0.707106781,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST jointtarget Jhome:=[[0,0,-90,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];

    VAR num nTorre := 0; ! N�mero de torres
    VAR num cont := 0;  ! Contador de piezas
    VAR num h1 := 0;    ! Torre 1
    VAR num h2 := 0;    ! Torre 2
    VAR num h3 := 0;    ! Torre 3
    VAR num hPieza := 20;   ! Altura de la pieza

PROC main()
    Initialize; ! Inicializamos la estaci�n y vamos al punto de reposo
    MoveJ Reposo, v500, fine, TVentosa \WObj:=wobj0;
    WHILE cont < 10 DO ! El bucle se mantendra hasta que posicionemos 10 piezas
        Pick PP;
        TPReadNum nTorre, "Introduce el numero de torre (1 para PB1, 2 para PB2, 3 para PB3):"; ! Introducimos el numero de la torre en la que queremos colocar la pieza
        IF nTorre = 1 THEN
            Place(Offs(PB1, 0, 0,h1)); ! Dejamos la pieza en la base
            h1 := h1 + hPieza; ! Actualizamos el valor de la altura
        ELSEIF nTorre = 2 THEN
            Place(Offs(PB2, 0, 0,h2));
            h2 := h2 + hPieza;
        ELSEIF nTorre = 3 THEN
            Place(Offs(PB3, 0, 0,h3));
            h3 := h3 + hPieza;
        ENDIF
        cont := cont + 1; ! Actualizamos el contador 
    ENDWHILE
    MoveJ Reposo, v500, fine, TVentosa \WObj:=wobj0; ! Cuando acabe el bucle, se vuelve al punto de partida mediante el punto de reposo
    MoveAbsJ Jhome, v500, fine, TVentosa;
ENDPROC

    PROC Initialize() ! Programa para inicializar la estaci�n
        cont := 0;
        h1 := 0;
        h2 := 0;
        h3 := 0;
        SetDO DTool, 0;
        MoveAbsJ Jhome, v200, fine, TVentosa;
    ENDPROC
    
PROC Place(robtarget punto) ! Programa para posicionar la pieza en las bases
    MoveJ Offs(punto, 0, 0, hPieza + 50), v500, z50, TVentosa \WObj:=WO_Base; ! Aproximaci�n por encima de la base
    MoveL Offs(punto, 0, 0, hPieza), v100, fine, TVentosa \WObj:=WO_Base;     ! Desciende lentamente hasta poner la pieza
    SetDO DTool, 0; ! Apaga la ventosa 
    WaitTime 0.5;   ! Espera a que la pieza se suelte
    MoveL Offs(punto, 0, 0, hPieza + 50), v500, z50, TVentosa \WObj:=WO_Base; ! Retrocede verticalmente 
ENDPROC

PROC Pick(robtarget punto) ! Programa para coger la pieza
    MoveJ Offs(punto, 0, 0, 50), v500, z50, TVentosa \WObj:=WO_Pieza;  ! Aproximaci�n por encima de la pieza
    MoveL punto, v100, fine, TVentosa \WObj:=WO_Pieza;                  ! Desciende lentamente hasta contactar con la pieza
    SetDO DTool, 1; ! Activa la ventosa 
    WaitTime 0.5;   ! Espera a que la pieza se coja correctamente
    MoveL Offs(punto, 0, 0, 150), v500, fine, TVentosa \WObj:=WO_Pieza; ! Eleva la pieza a una altura para esperar
ENDPROC

ENDMODULE